// src/utils/apiResponse.js

/**
 * Standardised API response envelope.
 * All endpoints return: { success, message, data?, errors?, meta? }
 */

const sendSuccess = (res, { statusCode = 200, message = 'OK', data = null, meta = null } = {}) => {
  const body = { success: true, message };
  if (data !== null) body.data = data;
  if (meta !== null) body.meta = meta;
  return res.status(statusCode).json(body);
};

const sendError = (res, { statusCode = 500, message = 'Internal server error', errors = null } = {}) => {
  const body = { success: false, message };
  if (errors !== null) body.errors = errors;
  return res.status(statusCode).json(body);
};

module.exports = { sendSuccess, sendError };

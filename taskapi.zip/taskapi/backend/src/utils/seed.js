// src/utils/seed.js
require('dotenv').config();
const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');

const prisma = new PrismaClient();

async function main() {
  const existing = await prisma.user.findUnique({ where: { email: 'admin@taskapi.com' } });
  if (existing) {
    console.log('Admin user already exists, skipping seed.');
    return;
  }

  const passwordHash = await bcrypt.hash('Admin@123', 12);
  const admin = await prisma.user.create({
    data: {
      email: 'admin@taskapi.com',
      username: 'admin',
      passwordHash,
      role: 'ADMIN',
    },
  });

  console.log('Seeded admin user:', admin.email);
  console.log('Password: Admin@123');
}

main()
  .catch(console.error)
  .finally(() => prisma.$disconnect());

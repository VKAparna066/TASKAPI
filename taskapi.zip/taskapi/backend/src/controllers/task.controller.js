// src/controllers/task.controller.js
const xss = require('xss');
const prisma = require('../config/prisma');
const { sendSuccess, sendError } = require('../utils/apiResponse');

// GET /api/v1/tasks  (own tasks; admin sees all)
const listTasks = async (req, res, next) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const skip = (page - 1) * limit;

    const where = {
      ...(req.user.role !== 'ADMIN' && { userId: req.user.id }),
      ...(req.query.status && { status: req.query.status }),
      ...(req.query.priority && { priority: req.query.priority }),
    };

    const [tasks, total] = await Promise.all([
      prisma.task.findMany({
        where,
        skip,
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: {
          user: { select: { id: true, username: true, email: true } },
        },
      }),
      prisma.task.count({ where }),
    ]);

    return sendSuccess(res, {
      data: { tasks },
      meta: {
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit),
      },
    });
  } catch (err) {
    next(err);
  }
};

// GET /api/v1/tasks/:id
const getTask = async (req, res, next) => {
  try {
    const task = await prisma.task.findUnique({
      where: { id: req.params.id },
      include: { user: { select: { id: true, username: true, email: true } } },
    });

    if (!task) return sendError(res, { statusCode: 404, message: 'Task not found' });
    if (req.user.role !== 'ADMIN' && task.userId !== req.user.id) {
      return sendError(res, { statusCode: 403, message: 'Access denied' });
    }

    return sendSuccess(res, { data: { task } });
  } catch (err) {
    next(err);
  }
};

// POST /api/v1/tasks
const createTask = async (req, res, next) => {
  try {
    const { title, description, status, priority, dueDate } = req.body;

    const task = await prisma.task.create({
      data: {
        title: xss(title.trim()),
        description: description ? xss(description.trim()) : null,
        status: status || 'TODO',
        priority: priority || 'MEDIUM',
        dueDate: dueDate ? new Date(dueDate) : null,
        userId: req.user.id,
      },
    });

    return sendSuccess(res, { statusCode: 201, message: 'Task created', data: { task } });
  } catch (err) {
    next(err);
  }
};

// PATCH /api/v1/tasks/:id
const updateTask = async (req, res, next) => {
  try {
    const existing = await prisma.task.findUnique({ where: { id: req.params.id } });
    if (!existing) return sendError(res, { statusCode: 404, message: 'Task not found' });
    if (req.user.role !== 'ADMIN' && existing.userId !== req.user.id) {
      return sendError(res, { statusCode: 403, message: 'Access denied' });
    }

    const { title, description, status, priority, dueDate } = req.body;
    const updateData = {};
    if (title !== undefined) updateData.title = xss(title.trim());
    if (description !== undefined) updateData.description = xss(description.trim());
    if (status !== undefined) updateData.status = status;
    if (priority !== undefined) updateData.priority = priority;
    if (dueDate !== undefined) updateData.dueDate = dueDate ? new Date(dueDate) : null;

    const task = await prisma.task.update({ where: { id: req.params.id }, data: updateData });
    return sendSuccess(res, { message: 'Task updated', data: { task } });
  } catch (err) {
    next(err);
  }
};

// DELETE /api/v1/tasks/:id
const deleteTask = async (req, res, next) => {
  try {
    const existing = await prisma.task.findUnique({ where: { id: req.params.id } });
    if (!existing) return sendError(res, { statusCode: 404, message: 'Task not found' });
    if (req.user.role !== 'ADMIN' && existing.userId !== req.user.id) {
      return sendError(res, { statusCode: 403, message: 'Access denied' });
    }

    await prisma.task.delete({ where: { id: req.params.id } });
    return sendSuccess(res, { message: 'Task deleted' });
  } catch (err) {
    next(err);
  }
};

module.exports = { listTasks, getTask, createTask, updateTask, deleteTask };

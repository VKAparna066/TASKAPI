// src/controllers/admin.controller.js
const prisma = require('../config/prisma');
const { sendSuccess, sendError } = require('../utils/apiResponse');

// GET /api/v1/admin/users
const listUsers = async (req, res, next) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 20;
    const skip = (page - 1) * limit;

    const [users, total] = await Promise.all([
      prisma.user.findMany({
        skip,
        take: limit,
        select: {
          id: true, email: true, username: true, role: true,
          createdAt: true, _count: { select: { tasks: true } },
        },
        orderBy: { createdAt: 'desc' },
      }),
      prisma.user.count(),
    ]);

    return sendSuccess(res, {
      data: { users },
      meta: { total, page, limit, totalPages: Math.ceil(total / limit) },
    });
  } catch (err) {
    next(err);
  }
};

// PATCH /api/v1/admin/users/:id/role
const updateUserRole = async (req, res, next) => {
  try {
    const { role } = req.body;
    if (!['USER', 'ADMIN'].includes(role)) {
      return sendError(res, { statusCode: 400, message: 'Role must be USER or ADMIN' });
    }

    const user = await prisma.user.update({
      where: { id: req.params.id },
      data: { role },
      select: { id: true, email: true, username: true, role: true },
    });

    return sendSuccess(res, { message: 'Role updated', data: { user } });
  } catch (err) {
    next(err);
  }
};

// DELETE /api/v1/admin/users/:id
const deleteUser = async (req, res, next) => {
  try {
    if (req.params.id === req.user.id) {
      return sendError(res, { statusCode: 400, message: 'Cannot delete your own account' });
    }
    await prisma.user.delete({ where: { id: req.params.id } });
    return sendSuccess(res, { message: 'User deleted' });
  } catch (err) {
    next(err);
  }
};

// GET /api/v1/admin/stats
const getStats = async (req, res, next) => {
  try {
    const [totalUsers, totalTasks, tasksByStatus, tasksByPriority] = await Promise.all([
      prisma.user.count(),
      prisma.task.count(),
      prisma.task.groupBy({ by: ['status'], _count: { _all: true } }),
      prisma.task.groupBy({ by: ['priority'], _count: { _all: true } }),
    ]);

    return sendSuccess(res, {
      data: {
        totalUsers,
        totalTasks,
        tasksByStatus: Object.fromEntries(tasksByStatus.map((r) => [r.status, r._count._all])),
        tasksByPriority: Object.fromEntries(tasksByPriority.map((r) => [r.priority, r._count._all])),
      },
    });
  } catch (err) {
    next(err);
  }
};

module.exports = { listUsers, updateUserRole, deleteUser, getStats };

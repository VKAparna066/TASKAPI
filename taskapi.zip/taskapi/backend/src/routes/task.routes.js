// src/routes/task.routes.js
const { Router } = require('express');
const { listTasks, getTask, createTask, updateTask, deleteTask } = require('../controllers/task.controller');
const { createTaskValidation, updateTaskValidation, listTasksValidation } = require('../validators/task.validators');
const validate = require('../middleware/validate');
const { authenticate } = require('../middleware/auth');

const router = Router();

// All task routes require authentication
router.use(authenticate);

router.get('/', listTasksValidation, validate, listTasks);
router.get('/:id', getTask);
router.post('/', createTaskValidation, validate, createTask);
router.patch('/:id', updateTaskValidation, validate, updateTask);
router.delete('/:id', deleteTask);

module.exports = router;

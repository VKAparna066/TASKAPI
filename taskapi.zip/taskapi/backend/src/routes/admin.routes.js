// src/routes/admin.routes.js
const { Router } = require('express');
const { listUsers, updateUserRole, deleteUser, getStats } = require('../controllers/admin.controller');
const { authenticate, authorize } = require('../middleware/auth');

const router = Router();

// All admin routes require authentication + ADMIN role
router.use(authenticate, authorize('ADMIN'));

router.get('/stats', getStats);
router.get('/users', listUsers);
router.patch('/users/:id/role', updateUserRole);
router.delete('/users/:id', deleteUser);

module.exports = router;

// src/middleware/errorHandler.js
const logger = require('../utils/logger');
const { sendError } = require('../utils/apiResponse');

// Central error handler – must be registered last
const errorHandler = (err, req, res, next) => {
  logger.error(`${req.method} ${req.originalUrl} — ${err.message}`, { stack: err.stack });

  // Prisma unique constraint violation
  if (err.code === 'P2002') {
    const field = err.meta?.target?.[0] || 'field';
    return sendError(res, { statusCode: 409, message: `A record with that ${field} already exists` });
  }

  // Prisma record not found
  if (err.code === 'P2025') {
    return sendError(res, { statusCode: 404, message: 'Record not found' });
  }

  const statusCode = err.statusCode || 500;
  const message =
    process.env.NODE_ENV === 'production' && statusCode === 500
      ? 'Internal server error'
      : err.message;

  return sendError(res, { statusCode, message });
};

// 404 for unmatched routes
const notFound = (req, res) => {
  return sendError(res, {
    statusCode: 404,
    message: `Route ${req.method} ${req.originalUrl} not found`,
  });
};

module.exports = { errorHandler, notFound };

# Scalability Notes

## Current Architecture
Single Node.js + PostgreSQL service suited for development and small-to-medium deployments.

## Horizontal Scaling Path

### 1. Stateless API layer → multiple instances
JWT tokens are stateless — no server-side session state. Any instance can verify any token.
Run N backend replicas behind a load balancer (NGINX, AWS ALB) without sticky sessions.

### 2. Database connection pooling
Use PgBouncer or Prisma's built-in pool to handle hundreds of connections without exhausting PostgreSQL's process limit.

### 3. Caching layer (Redis)
- Cache `GET /tasks` query results with short TTL (e.g. 10s) to reduce DB reads under spiky traffic
- Rate limiter state shared across instances via Redis (swap `express-rate-limit` to `rate-limit-redis`)
- Session/refresh token blacklist on logout

### 4. Message queue for async work
Offload email notifications, audit logging, and webhooks to a queue (BullMQ on Redis / SQS).

### 5. Microservices extraction
When distinct domains grow large, extract:
- **Auth service** (handles users, tokens)
- **Task service** (CRUD, notifications)
- **Admin service** (analytics, moderation)

Services communicate via REST or gRPC; share an API Gateway (Kong, AWS API GW).

### 6. Database scaling
- Read replicas for heavy read workloads (`SELECT` queries → replica, writes → primary)
- Table partitioning on `tasks` by `created_at` for multi-million-row tables
- Migrate to Citus (distributed Postgres) or move to DynamoDB/Cassandra if requirements demand it

### 7. Observability
- Structured JSON logs → Datadog / Loki
- Distributed tracing → OpenTelemetry + Jaeger
- Metrics → Prometheus + Grafana

### 8. Container deployment
The included `Dockerfile` and `docker-compose.yml` provide a starting point.
For production: Kubernetes (EKS/GKE) with HPA (Horizontal Pod Autoscaler) based on CPU/memory/request-rate.

## Security hardening (production checklist)
- [ ] Rotate JWT secrets via environment secrets manager (AWS Secrets Manager / HashiCorp Vault)
- [ ] Enable HTTPS (TLS termination at load balancer)
- [ ] Set `NODE_ENV=production` (disables stack traces in error responses)
- [ ] Configure `helmet` CSP headers
- [ ] Database credentials via secrets, never `.env` in container image
- [ ] Enable PostgreSQL SSL (`?sslmode=require` in `DATABASE_URL`)
